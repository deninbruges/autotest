import javafx.scene.chart.BubbleChart;
import junit.framework.Assert;
import org.apache.http.auth.BasicUserPrincipal;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;
import java.lang.*;
import java.security.Key;
import java.util.concurrent.TimeUnit;

import static java.lang.Thread.sleep;

public class SimpleTest {
    String Actualtext;

    @Test
    public void navigateToGoogleWebSiteAndSearchIphone() throws InterruptedException {
        System.setProperty("webdriver.chrome.driver","C:\\sel\\chromedriver.exe");
        WebDriver driver = new ChromeDriver();
        driver.manage().window().maximize();
       driver.get("https://cian.ru/");

        driver.findElement(By.xpath("//*[@id=\"header-top\"]/div[1]/div/a[1]")).click();
        System.out.println("Проверка ссылки Каталог специалистов");
        Assert.assertTrue(driver.getCurrentUrl().contains("/agentstva/"));


       driver.findElement(By.linkText("Поиск по карте")).click();
        System.out.println("Проверка ссылки Поиск по карте");
        Assert.assertTrue(driver.getCurrentUrl().contains("/map/"));

       driver.findElement(By.linkText("Оценка квартир")).click();
        System.out.println("Проверка ссылки Оценка");
        Assert.assertTrue(driver.getCurrentUrl().contains("/kalkulator-nedvizhimosti/"));

        driver.findElement(By.linkText("Журнал")).click();
        System.out.println("Проверка ссылки Журнал");
        Assert.assertTrue(driver.getCurrentUrl().contains("/magazine/"));


       driver.findElement(By.linkText("Вопросы риэлтору")).click();
       System.out.println("Проверка ссылки Вопросы риэлтору");
       Assert.assertTrue(driver.getCurrentUrl().contains("/forum-rieltorov/"));


        driver.findElement(By.linkText("Аренда")).click();
        System.out.println("Проверка ссылки Аренда");
        Assert.assertTrue(driver.getCurrentUrl().contains("/snyat/"));

        driver.findElement(By.linkText("Продажа")).click();
        System.out.println("Проверка ссылки Продажа");
        Assert.assertTrue(driver.getCurrentUrl().contains("/kupit/"));

        driver.findElement(By.linkText("Новостройки")).click();
        System.out.println("Проверка ссылки Новостройки");
        Assert.assertTrue(driver.getCurrentUrl().contains("/novostrojki/"));

        driver.findElement(By.linkText("Коммерческая")).click();
        System.out.println("Проверка ссылки Коммерческая");
        Assert.assertTrue(driver.getCurrentUrl().contains("/commercial/"));

        driver.findElement(By.linkText("Ипотека")).click();
        System.out.println("Проверка ссылки Ипотека");
        Assert.assertTrue(driver.getCurrentUrl().contains("/ipoteka/"));

        driver.get("https://www.cian.ru/kupit-kvartiru/");


        driver.findElement(By.cssSelector("#frontend-serp > div > div._93444fe79c-supports-sticky--30VbT > div > div > div:nth-child(2) > div._93444fe79c-filters-item--2PZQj._93444fe79c-geoSuggest--3z_v0 > span > div > span > input")).click();
        Thread.sleep(2500);
        driver.findElement(By.cssSelector("#frontend-serp > div > div._93444fe79c-supports-sticky--30VbT > div > div > div:nth-child(2) > div._93444fe79c-filters-item--2PZQj._93444fe79c-geoSuggest--3z_v0 > span > div > span > input")).sendKeys("Чебоксары");
        Thread.sleep(2500);
        driver.findElement(By.cssSelector("#frontend-serp > div > div._93444fe79c-supports-sticky--30VbT > div > div > div:nth-child(2) > div._93444fe79c-filters-item--2PZQj._93444fe79c-geoSuggest--3z_v0 > span > div > span > input")).sendKeys(Keys.RETURN);
        Thread.sleep(2500);
        driver.findElement(By.xpath("//button[contains(text(),'Комнат')]")).click();
        driver.findElement(By.xpath("//label[contains(text(),'1-комнатная')]")).click();
        Thread.sleep(2500);
        driver.findElement(By.xpath("//button[contains(text(),'объектов')]")).click();

/**  Здесь должна быть проверка на выдачу результата поиска, но что-то через раз работает она.
        Actualtext = driver.findElement(By.xpath("//*[@id=\"frontend-serp\"]/div/div[3]/div/div/div[1]")).getText();
        Assert.assertEquals(Actualtext, "Ничего не найдено");
        System.out.println("Результаты поиска есть");
*/

        //System.out.println(driver.getCurrentUrl());
        //System.out.println(driver.getTitle());
        //driver.quit();
    }
}

